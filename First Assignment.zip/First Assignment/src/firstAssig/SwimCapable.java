package firstAssig;

public interface SwimCapable {//Abstraction: interface
	void swim();
}
