package firstAssig;

public class Biped extends AnimalMain {
//Inherited class
	public Biped() {
		super();
	}
	public Biped(String speciesName)
	{
		legs=2;// because its a biped, we already know the leg number, and can exploit that here. 
		//also this is Overloading the constructors another example of Polymorphism 
		species=speciesName;
	}
	public Biped(String speciesName, int legNo)
	{
		super(speciesName, legNo);
	}
	@Override
	public int hashCode() {
		return super.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}
	

}
