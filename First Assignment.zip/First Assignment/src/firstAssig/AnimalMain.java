/**
 * 
 */
package firstAssig;


/**
 * @author Casey Andres
 *
 */
public class AnimalMain {
	String species;
	int legs;
	private double DNA; // Encapsulated data
	public AnimalMain() {
		species="none";
		legs=0;
		DNA=0;
	}
	public AnimalMain(String speciesName, int legNo) // Overloaded Constructor polymorphism
	{
		species=speciesName;
		
		try {
			if(legNo>=0)
			legs=legNo;
			else
			throw new negativeLegsException();
		}
		catch(negativeLegsException e){
			System.out.println("You Cannot enter a negative number of legs");
		}
		
		DNA=0;
	}
	public void setDNA(double DNANo)
	{
		DNA=DNANo;// Abstraction of a Private Var.
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(DNA);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + legs;
		result = prime * result + ((species == null) ? 0 : species.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AnimalMain other = (AnimalMain) obj;
		if (Double.doubleToLongBits(DNA) != Double.doubleToLongBits(other.DNA))
			return false;
		if (legs != other.legs)
			return false;
		if (species == null) {
			if (other.species != null)
				return false;
		} else if (!species.equals(other.species))
			return false;
		return true;
	}
}
