package firstAssig;

import firstAssig.AnimalMain;

public class Fish extends AnimalMain implements SwimCapable {

	public Fish() {
		super();
	}
	public Fish (String name, int legs)
	{
		super(name, 0);//fish don't have legs
	}
	public void swim()
	{
		return;
	}
	@Override
	public int hashCode() {
		return super.hashCode();
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		return true;
	}

}
